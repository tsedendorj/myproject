<?php require 'functions/config.php'; ?>
<?php include '_main_header.php'; ?>
<?php include '_site_top.php'; ?>
   
   
   
   <section class="main-content">
     <div class="container">
       <div class="row" style="background-color: #fff; padding-top: 15px; padding-bottom: 15px;">
         <div class="col-md-9">
           
           <div class="row">
              <?php foreach(get_all_post() as $row): ?>
              <div class="col-md-6">
                <div class="news-item">
                  <div class="news-img">
                    <a href="read.php?id=<?php echo $row['id']; ?>">
                      <img src="/uploads/<?php echo $row['image']; ?>" alt="">
                    </a>
                  </div>
                  <h3>
                    <a href="read.php?id=<?php echo $row['id']; ?>"><?php echo $row['title']; ?></a>
                  </h3>
                  <p><?php echo $row['description']; ?></p>
                  <small><i class="far fa-clock"></i> <?php echo $row['created_at']; ?></small>
                </div>              
              </div>
              <?php endforeach; ?>
             
           </div>
           
           
         </div>
         <div class="col-md-3"></div>
       </div>
     </div>
     
   </section>
   
   
   

<?php include '_main_footer.php'; ?>