<?php 
session_start();

if (function_exists('header_remove')) {
    header_remove('X-Powered-By'); // PHP 5.3+
} else {
    @ini_set('expose_php', 'off');
}

require 'functions/config.php'; 

if( isset($_POST['submit']) ){
  
  $u = $_POST['user'];
  $p = $_POST['pass'];
  
  if( empty($u) or empty($p) ){
    $error = 'Уучлаарай утгуудаа оруулна уу';
  } else {
    
    if( check_user($u, $p) ){
      $_SESSION['u'] = $u;
      $_SESSION['p'] = $p;
      header('Location: post_list.php');
      die();
    }else{
      $error = 'Уучлаарай нэр эсвэл нууц үг буруу';
    }
    
  }
} 

?>
<?php include '_header.php'; ?>

<div class="container">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      
      <div class="adminbox" style="margin-top: 40%;">
       
        <h3>Нэвтрэх хэсэг</h3>
        
        <?php if( isset($error) ){ ?>
        <div class="alert alert-danger">
        <?php echo $error; ?>
        </div>
        <?php } ?>
        
        <form action="" method="post">
         
         <div class="form-group">
           <input type="text" name="user" class="form-control" placeholder="Хэрэглэгчийн нэр">
         </div>
         
         <div class="form-group">
           <input type="password" name="pass" class="form-control" placeholder="Нууц үг">
         </div>
         
         <button type="submit" name="submit" class="btn btn-primary">Нэвтрэх</button>
          
        </form>
      </div>
      
    </div>
    <div class="col-md-4"></div>
    
  </div>
</div>


<?php include '_footer.php'; ?>