<?php
session_start();
require 'functions/config.php'; 

if( !check_user($_SESSION['u'], $_SESSION['p']) ){
  header('Location: login.php');
  die();
}

if( isset($_GET['delete']) ){
  $id = $_GET['delete'];
  delete_item($id);
  header('Location: category.php');
  die();
}


if( isset($_GET['submit']) ){
  
  $c = $_GET['angilal'];
  
  if( empty($c) ){
    $error = 'uuchlaarai hooson bn';
  }else{
    //hadgalah uildel end bn
    
    add_new_category($c);
    header('Location: category.php');
    die();
  }
}

?>
<?php include '_header.php'; ?>
    
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          
          <div class="adminbox">
            
            <h3>Ангилал нэмэх хэсэг</h3>
            
            <?php if( isset($error) ){ ?>
            <div class="alert alert-danger">
            Уучлаарай утга хоосон байна. Нэрээ оруулна уу
            </div>
            <?php } ?>
            
            <form action="" method="get">
              <div class="form-group">
                <label for="">Ангилал</label>
                <input type="text" name="angilal" class="form-control">
              </div>
              <button type="submit" name="submit" class="btn btn-success">Нэмэх</button>
              
            </form>
    
          </div>
          
        </div>
        <div class="col-md-6">
          
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Дд</th>
                <th>Нэр</th>
                <th>Үйлдэл</th>
              </tr>
            </thead>
            <tbody>
              <?php $categories = get_all_category(); ?>
              <?php foreach($categories as $row){ ?>
              <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td>
                  <a class="btn btn-danger btn-sm" href="?delete=<?php echo $row['id']; ?>">Устгах</a>
                </td>
              </tr>
              <?php } ?>
              
            </tbody>
          </table>
          
          
        </div>
      </div>
    </div>
    

<?php include '_footer.php'; ?>