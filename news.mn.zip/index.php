<?php require 'functions/config.php'; ?>
<?php include '_main_header.php'; ?>
<?php include '_site_top.php'; ?>
   
   
   
   <section class="main-content">
     
   </section>
   
   
   

<?php include '_main_footer.php'; ?>