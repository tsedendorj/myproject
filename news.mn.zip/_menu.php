<?php $user = get_user_info($_SESSION['u'], $_SESSION['p']); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary" style="margin-bottom: 30px;">
  <a class="navbar-brand" href="#">Админ хуудас</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
     
      <?php if($user[0]['role']==1): ?> 
      <li class="nav-item">
        <a class="nav-link" href="post_list.php">Мэдээний жагсаалт</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="add_post.php">Мэдээ нэмэх</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hi <?php echo $user[0]['display_name']; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="">Нууц үгээ солих</a>
          <a class="dropdown-item" href="#">Захиа шалгах</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php">Системээс гарах</a>
        </div>
      </li>
      <?php endif; ?>
      
      <?php if($user[0]['role']==2): ?>
      <li class="nav-item">
        <a class="nav-link" href="post_list.php">Мэдээний жагсаалт</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="add_post.php">Мэдээ нэмэх</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="category.php">Ангилал</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="member.php">Хэрэглэгч</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hi <?php echo $user[0]['display_name']; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="">Нууц үгээ солих</a>
          <a class="dropdown-item" href="#">Захиа шалгах</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php">Системээс гарах</a>
        </div>
      </li>
      <?php endif; ?>
      
    </ul>

  </div>
</nav>